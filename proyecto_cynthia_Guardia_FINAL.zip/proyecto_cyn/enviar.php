﻿<!doctype html>
<html lang="es">
<head>
    <title>Proyecto web Tecnologia Multimedia</title>
    <meta charset="utf-8">
    <title>Proyecto Web</title>
    <link rel="stylesheet" type="text/css" href="estilos.css">
    <link rel="stylesheet" type="text/css" href="normalize.css">
    <meta name="viewport" content="width=device-width,maximun-scale=1">

    <script type="text/javascript" src="Scripts/AC_RunActiveContent.js"></script>
     <script type="text/javascript" src="js/jquery_min.js"></script>
     <script type="text/javascript" src="js/slimbox2.js"></script>
    <link rel="stylesheet" type="text/css" href="css/slimbox2.css" media="screen"/>
</head>
<body>
      <header>
             <figure id="avatar">
             <img src="avatar.jpg">
             </figure>
             <figure id="logo">
             <img src="logo.png" >
             </figure>
             <h1>Proyecto Web</h1>
      </header>

      <nav>
           <ul>
              <li><a href="index.html">Inicio</a></li>
               <li><a href="nosotros.html">Nosotros</a></li>
               <li><a href="libros.html">Nuevos libros</a></li>
               <li><a href="galeria.html">Galeria</a></li>
               <li><a href="productos.html">Productos</a></li>
               <li id="publicar_nav">
                <a href="contacto.html">Contacto</a>
               </li>
           </ul>
      </nav>

      <section id="contenido">
      	 <article class="item1">
      	 	<form action="enviar.php" method="post">
            <input class="item1_cuadro1" type="text" placeholder="Ingrese su Email"name="asunto"><br><br>
            <textarea class="item1_cuadro1" placeholder="Escriba su Mensaje" name="mensaje"></textarea><br><br>
            <button class="item_button" type="submit" name="enviar">Contáctame</button>
          </form>

          <?php
          if(isset($_POST['asunto'])&& !empty($_POST['asunto']) && 
            isset($_POST['mensaje'])&& !empty($_POST['mensaje'])
            )
          {
            $destino ="cynmeli.cg@gmail.com";
            $desde ="From" . "TuNombre";
            $asunto=$_POST['asunto'];
            $mensaje=$_POST['mensaje'];
            //funcion mail, permite enviar mensaje
            mail($destino,$asunto,$mensaje,$desde);
           // echo "Correo Enviado...";
            echo '<script language="Javascript">alert("Correo enviado")</script>';
          }else
          {
            echo "Problemas al enviar";
          }
          php?>

      	 </article>
      </section>

      <footer>
      	<p><strong>Diseñando por Cynthia Guardia Poclin</strong></p>
      	<p>Tecnologia Multimedia</p>
      </footer>

</body>
</html>